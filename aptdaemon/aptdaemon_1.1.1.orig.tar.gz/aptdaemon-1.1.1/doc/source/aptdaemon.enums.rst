:mod:`aptdaemon.enums` --- The enums module
===========================================

.. automodule:: aptdaemon.enums
    :members:
