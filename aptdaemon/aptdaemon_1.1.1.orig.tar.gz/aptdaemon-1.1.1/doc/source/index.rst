Aptdaemon documentation
=======================

Contents:

.. toctree::
   :maxdepth: 2

   aptdaemon.client
   aptdaemon.enums
   aptdaemon.gtk3widgets

   dbus
   plugins

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

